ERNO ICARDNAME - FRONT-END PROJECT
=================================
Folders:
- Client: Home, About, Contact, Login/Sign up, Product pages
- Admin: Profile, Client List, Order List, Login, Feedback Review pages
- assets: shared CSS and JavaScript

HOW TO RUN:
1. Extract this ZIP.
2. Open the Client folder and double-click "1- Home Page.html".
3. Use the navigation links to move between pages.
4. Admin pages are inside the Admin folder.

IMPORTANT:
This is a front-end demonstration using HTML, CSS and JavaScript.
Forms demonstrate client-side validation only. They do not save data or
authenticate users. A backend and database are required for real login,
orders, clients and feedback.

Student Name: Milan
Enrollment Number: 92610120103

