function showMessage(id, message, good=false){
 const el=document.getElementById(id); if(el){el.textContent=message;el.className=good?'success':'error';}
}
function validateContact(e){
 e.preventDefault(); const f=e.target;
 if(!f.name.value.trim()||!f.email.value.trim()||!f.message.value.trim()){showMessage('formMsg','All fields are required.');return false;}
 if(!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(f.email.value)){showMessage('formMsg','Enter a valid email address.');return false;}
 showMessage('formMsg','Message validated successfully (demo only).',true); f.reset(); return false;
}
function validateLogin(e){
 e.preventDefault();const f=e.target;
 if(!f.email.value.trim()||!f.password.value){showMessage('formMsg','All fields are required.');return false;}
 if(!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(f.email.value)){showMessage('formMsg','Enter a valid email.');return false;}
 if(f.password.value.length<8){showMessage('formMsg','Password must be at least 8 characters.');return false;}
 showMessage('formMsg','Input validation successful. Demo only; no account is created.',true);return false;
}
function validateSignup(e){
 e.preventDefault();const f=e.target;
 if(!f.name.value.trim()||!f.email.value.trim()||!f.phone.value.trim()||!f.password.value||!f.confirm.value){showMessage('formMsg','All fields are required.');return false;}
 if(!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(f.email.value)){showMessage('formMsg','Invalid email pattern.');return false;}
 if(!/^[6-9]\\d{9}$/.test(f.phone.value)){showMessage('formMsg','Enter a valid 10-digit Indian mobile number.');return false;}
 if(!/^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}$/.test(f.password.value)){showMessage('formMsg','Use 8+ characters with uppercase, lowercase, number and symbol.');return false;}
 if(f.password.value!==f.confirm.value){showMessage('formMsg','Passwords do not match.');return false;}
 showMessage('formMsg','All validations passed (demo only).',true);return false;
}